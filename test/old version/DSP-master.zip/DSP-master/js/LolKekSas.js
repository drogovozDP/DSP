function dickSusCock()
{
    let a = document.getElementsByClassName('graphCollection');
    a[0].style.background;
    alert(a.length);
}